class Player{
    constructor(){
        this.x = 0;
        this.y = 0;
        this.look_h = 0;
        this.look_v = 0;
    }
}

module.exports = Player;