var socket = io.connect('http://52.68.111.88:6666');

socket.on("roominfo",roomdata=>{
    document.getElementById();
});